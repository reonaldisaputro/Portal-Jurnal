<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="<?php echo e(asset('output.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('main.css')); ?>" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap"
        rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="font-[Poppins] bg-[#F9F9FC]">
    <?php if (isset($component)) { $__componentOriginala591787d01fe92c5706972626cdf7231 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala591787d01fe92c5706972626cdf7231 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $attributes = $__attributesOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__attributesOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $component = $__componentOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__componentOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
    <nav id="Category" class="max-w-[1130px] md:mx-auto mx-3 grid md:grid-cols-3 gap-4 mt-[30px]">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('front.category', $category->slug)); ?>"
                class="rounded-full p-[12px_22px] flex gap-[10px] font-semibold transition-all duration-300 border border-[#EEF0F7] hover:ring-2 hover:ring-[#FF6B18] bg-white">
                <!-- Tambahkan bg-white -->
                
                <span><?php echo e($category->name); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>
    <section class="max-w-[1130px] my-10 md:mx-auto mx-3 bg-white rounded-xl">
        <div class="flex items-center gap-6 py-5 px-5">
            <div class="md:w-52 md:h-52 w-44 h-44 flex rounded-full overflow-hidden">
                <img src="<?php echo e(Storage::url($author->avatar)); ?>" alt="Profile Photo" class="object-cover">
            </div>
            <div>
                <h1 class="text-[#5D5F65] text-3xl font-bold"><?php echo e($author->name); ?></h1>
                <p class="text-[#5D5F65]"><?php echo e($author->occupation); ?></p>
            </div>
        </div>
    </section>
    <section class="max-w-[1130px] md:flex justify-between gap-5 my-10 md:mx-auto mx-3">
        <div class="bg-white p-5">
            
            <p class="font-bold pt-3">Kategori</p>
            <div class="grid md:grid-cols-5 gap-2">
                <?php $__empty_1 = true; $__currentLoopData = $author->news->unique('category_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <button
                        class="border rounded-md shadow-lg py-3 px-3 text-[#FF6B18] hover:shadow-2xl"><?php echo e($news->category->name); ?></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>Belum ada artikel yang ditulis</p>
                <?php endif; ?>
            </div>
        </div>
        <div class="bg-white p-5">
            <div class="pb-3">
                <p class="font-bold">Angkatan</p>
                <p><?php echo e($author->angkatan); ?></p>
            </div>
            <div class="pb-3">
                <p class="font-bold">Jurusan</p>
                <p><?php echo e($author->jurusan); ?></p>
            </div>
            <a class="hover:underline">
                <p class="font-bold">Email</p>
                <p><?php echo e($author->email); ?></p>
            </a>
            <!-- Jika ada link ke Linkedin -->
            <?php if(!empty($author->linkedin)): ?>
                <a href="<?php echo e($author->linkedin); ?>" class="hover:underline py-3">
                    <p class="font-bold">Linkedin</p>
                    <p><?php echo e($author->linkedin); ?></p>
                </a>
            <?php endif; ?>

            <!-- Jika ada link ke Instagram -->
            <?php if(!empty($author->instagram)): ?>
                <a href="<?php echo e($author->instagram); ?>" class="hover:underline py-3">
                    <p class="font-bold">Instagram</p>
                    <p><?php echo e($author->instagram); ?></p> <!-- Username diambil dari field Instagram -->
                </a>
            <?php endif; ?>
            <!-- Jika ada link ke Instagram -->
            <?php if(!empty($author->youtube)): ?>
                <a href="<?php echo e($author->youtube); ?>" class="hover:underline py-3">
                    <p class="font-bold">Youtube</p>
                    <p><?php echo e($author->youtube); ?></p> <!-- Username diambil dari field Instagram -->
                </a>
            <?php endif; ?>
            <?php if(!empty($author->tiktok)): ?>
                <a href="<?php echo e($author->tiktok); ?>" class="hover:underline py-3">
                    <p class="font-bold">Tiktok</p>
                    <p><?php echo e($author->tiktok); ?></p> <!-- Username diambil dari field Instagram -->
                </a>
            <?php endif; ?>

            <!-- Jika ada link ke Twitter -->
            <?php if(!empty($author->twitter)): ?>
                <a href="<?php echo e($author->twitter); ?>" class="hover:underline">
                    <p class="font-bold">Twitter</p>
                    <p><?php echo e($author->twitter); ?></p> <!-- Username diambil dari field Twitter -->
                </a>
            <?php endif; ?>

        </div>
    </section>
    <section id="author" class="max-w-[1130px] md:mx-auto mx-3 flex flex-col gap-[30px] mt-[70px]">
        <div>
            <p class="font-bold text-2xl">Jurnal yang Dimiliki:</p>
        </div>
        <div id="content-cards" class="grid md:grid-cols-3 gap-[30px]">
            <?php $__empty_1 = true; $__currentLoopData = $author->news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('front.details', $news->slug)); ?>" class="card">
                    <div
                        class="flex flex-col gap-4 p-[26px_20px] transition-all duration-300 ring-1 ring-[#EEF0F7] hover:ring-2 hover:ring-[#FF6B18] rounded-[20px] overflow-hidden bg-white">
                        <div class="thumbnail-container h-[200px] relative rounded-[20px] overflow-hidden">
                            <div
                                class="badge absolute left-5 top-5 bottom-auto right-auto flex p-[8px_18px] bg-white rounded-[50px]">
                                <p class="text-xs leading-[18px] font-bold uppercase"><?php echo e($news->category->name); ?></p>
                            </div>
                            <img src="<?php echo e(Storage::url($news->thumbnail)); ?>" alt="thumbnail photo"
                                class="w-full h-full object-cover" />
                        </div>
                        <div class="flex flex-col gap-[6px]">
                            <h3 class="text-lg leading-[27px] font-bold"><?php echo e($news->name); ?></h3>
                            <p class="text-sm leading-[21px] text-[#A3A6AE]"><?php echo e($news->created_at->format('M d, Y')); ?>

                            </p>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Belum ada artikel yang ditulis</p>
            <?php endif; ?>

        </div>
    </section>
    <section class="max-w-[1130px] md:mx-auto mx-3 mt-[70px]">
        <p class="font-bold text-2xl">Rekomendasi Jurnal dari Penulis Lain:</p>
        <div id="content-cards" class="grid md:grid-cols-3 gap-[30px]">
            <?php $__empty_1 = true; $__currentLoopData = $author->news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('front.details', $news->slug)); ?>" class="card">
                    <div
                        class="flex flex-col gap-4 p-[26px_20px] transition-all duration-300 ring-1 ring-[#EEF0F7] hover:ring-2 hover:ring-[#FF6B18] rounded-[20px] overflow-hidden bg-white">
                        <div class="thumbnail-container h-[200px] relative rounded-[20px] overflow-hidden">
                            <div
                                class="badge absolute left-5 top-5 bottom-auto right-auto flex p-[8px_18px] bg-white rounded-[50px]">
                                <p class="text-xs leading-[18px] font-bold uppercase"><?php echo e($news->category->name); ?></p>
                            </div>
                            <img src="<?php echo e(Storage::url($news->thumbnail)); ?>" alt="thumbnail photo"
                                class="w-full h-full object-cover" />
                        </div>
                        <div class="flex flex-col gap-[6px]">
                            <h3 class="text-lg leading-[27px] font-bold"><?php echo e($news->name); ?></h3>
                            <p class="text-sm leading-[21px] text-[#A3A6AE]"><?php echo e($news->created_at->format('M d, Y')); ?>

                            </p>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Belum ada artikel yang ditulis</p>
            <?php endif; ?>

        </div>
    </section>
    <section class="max-w-[1130px] md:mx-auto mx-3 mt-[70px]">
        <p class="font-bold text-2xl">Jurnal Terkait:</p>
        <div id="content-cards" class="grid md:grid-cols-3 gap-[30px]">
            <?php $__empty_1 = true; $__currentLoopData = $author->news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('front.details', $news->slug)); ?>" class="card">
                    <div
                        class="flex flex-col gap-4 p-[26px_20px] transition-all duration-300 ring-1 ring-[#EEF0F7] hover:ring-2 hover:ring-[#FF6B18] rounded-[20px] overflow-hidden bg-white">
                        <div class="thumbnail-container h-[200px] relative rounded-[20px] overflow-hidden">
                            <div
                                class="badge absolute left-5 top-5 bottom-auto right-auto flex p-[8px_18px] bg-white rounded-[50px]">
                                <p class="text-xs leading-[18px] font-bold uppercase"><?php echo e($news->category->name); ?></p>
                            </div>
                            <img src="<?php echo e(Storage::url($news->thumbnail)); ?>" alt="thumbnail photo"
                                class="w-full h-full object-cover" />
                        </div>
                        <div class="flex flex-col gap-[6px]">
                            <h3 class="text-lg leading-[27px] font-bold"><?php echo e($news->name); ?></h3>
                            <p class="text-sm leading-[21px] text-[#A3A6AE]"><?php echo e($news->created_at->format('M d, Y')); ?>

                            </p>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Belum ada artikel yang ditulis</p>
            <?php endif; ?>

        </div>
    </section>
    <section id="Advertisement" class="max-w-[1130px] md:mx-auto mx-3 flex justify-center mt-[70px]">
        <div class="flex flex-col gap-3 shrink-0 w-full">
            <a href="<?php echo e($bannerads->link); ?>">
                <div class="w-full h-[120px] flex shrink-0 border border-[#EEF0F7] rounded-2xl overflow-hidden">
                    <img src="<?php echo e(Storage::url($bannerads->thumbnail)); ?>" class="object-cover w-full h-full"
                        alt="ads" />
                </div>
            </a>
            <p class="font-medium text-sm leading-[21px] text-[#A3A6AE] flex gap-1">
                Our Advertisement <a href="#" class="w-[18px] h-[18px]"><img
                        src="<?php echo e(asset('assets/images/icons/message-question.svg')); ?>" alt="icon" /></a>
            </p>
        </div>
    </section>
    <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH /Users/reonaldisaputro/Documents/Reonaldi/Portal-Berita/resources/views/front/author.blade.php ENDPATH**/ ?>